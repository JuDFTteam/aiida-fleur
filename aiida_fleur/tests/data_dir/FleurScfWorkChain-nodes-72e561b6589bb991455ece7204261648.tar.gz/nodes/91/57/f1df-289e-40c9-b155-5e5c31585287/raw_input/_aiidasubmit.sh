#!/bin/bash
exec > _scheduler-stdout.txt
exec 2> _scheduler-stderr.txt


export AIIDA_MOCK_LABEL=inpgen
export AIIDA_MOCK_DATA_DIR=/Users/broeder/aiida/github/aiida-fleur_dev/aiida-fleur/aiida_fleur/tests/workflows/calc_data_dir/
export AIIDA_MOCK_EXECUTABLE_PATH=~/codes/aiida/inpgen/max_r4/inpgen
export AIIDA_MOCK_IGNORE_FILES=_aiidasubmit.sh:FleurInputSchema.xsd

'/Users/broeder/aiida/envs/env_aiida_1_1/bin/aiida-mock-code' '-explicit' < 'aiida.in' > 'shell.out' 2> 'out.error'
