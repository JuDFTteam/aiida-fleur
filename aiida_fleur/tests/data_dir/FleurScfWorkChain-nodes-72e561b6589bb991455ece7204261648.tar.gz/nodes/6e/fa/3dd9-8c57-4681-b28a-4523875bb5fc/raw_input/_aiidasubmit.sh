#!/bin/bash
exec > _scheduler-stdout.txt
exec 2> _scheduler-stderr.txt
env --ignore-environment \


export AIIDA_MOCK_LABEL=fleur
export AIIDA_MOCK_DATA_DIR=/Users/broeder/aiida/github/aiida-fleur_dev/aiida-fleur/aiida_fleur/tests/workflows/calc_data_dir/
export AIIDA_MOCK_EXECUTABLE_PATH=~/codes/aiida/fleur/max_r4/serial/fleur
export AIIDA_MOCK_IGNORE_FILES=cdnc:out:FleurInputSchema.xsd:cdn.hdf:usage.json:cdn??

'mpirun' '-np' '1' '/Users/broeder/aiida/envs/env_aiida_1_1/bin/aiida-mock-code' '-minimalOutput' '-wtime' '5.0'  > 'shell.out' 2> 'out.error'
