#!/bin/bash
exec > _scheduler-stdout.txt
exec 2> _scheduler-stderr.txt


source ~/.bash_profile

'/Users/broeder/codes/aiida/inpgen/max_r4/inpgen' '-explicit' < 'aiida.in' > 'shell.out' 2> 'out.error'
