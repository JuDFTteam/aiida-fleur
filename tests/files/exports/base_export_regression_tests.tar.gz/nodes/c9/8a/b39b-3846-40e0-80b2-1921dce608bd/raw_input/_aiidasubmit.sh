#!/bin/bash
exec > _scheduler-stdout.txt
exec 2> _scheduler-stderr.txt
env --ignore-environment \


ulimit -s unlimited
source ~/.bash_profile

'mpirun' '-np' '1' '/Users/broeder/codes/aiida/fleur/max_r4/serial/fleur' '-minimalOutput' '-wtime' '360'  > 'shell.out' 2> 'out.error'
