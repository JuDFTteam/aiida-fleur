#!/bin/bash
exec > _scheduler-stdout.txt
exec 2> _scheduler-stderr.txt


'/Users/broeder/aiida/github/aiida-fleur_dev/aiida-fleur/aiida_fleur/tests/local_exe/inpgen' '-explicit' < 'aiida.in' > 'shell.out' 2> 'out.error'
