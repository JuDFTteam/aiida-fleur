#!/bin/bash
exec > _scheduler-stdout.txt
exec 2> _scheduler-stderr.txt
env --ignore-environment \

# ENVIRONMENT VARIABLES BEGIN ###
export OMP_NUM_THREADS='1'
# ENVIRONMENT VARIABLES  END  ###



'mpirun' '-np' '1' '/Users/broeder/aiida/github/aiida-fleur_dev/aiida-fleur/aiida_fleur/tests/fleur_code/fleur' '-minimalOutput' '-wtime' '60.0'  > 'shell.out' 2> 'out.error'
