#!/bin/bash
exec > _scheduler-stdout.txt
exec 2> _scheduler-stderr.txt
env --ignore-environment \


'mpirun' '-np' '1' '/Users/broeder/aiida/github/aiida-fleur_dev/aiida-fleur/aiida_fleur/tests/local_exe/fleur' '-minimalOutput' '-wtime' '10'  > 'shell.out' 2> 'out.error'
