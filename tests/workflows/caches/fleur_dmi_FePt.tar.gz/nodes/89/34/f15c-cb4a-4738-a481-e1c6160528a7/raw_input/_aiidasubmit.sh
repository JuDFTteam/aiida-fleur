#!/bin/bash
exec > _scheduler-stdout.txt
exec 2> _scheduler-stderr.txt
env --ignore-environment \


export AIIDA_MOCK_LABEL="fleur"
export AIIDA_MOCK_DATA_DIR="/builds/fleur/aiida-fleur/tests/workflows/calculations"
export AIIDA_MOCK_EXECUTABLE_PATH="/builds/fleur/aiida-fleur/tests/local_exe/fleur"
export AIIDA_MOCK_IGNORE_FILES="_aiidasubmit.sh"
export AIIDA_MOCK_IGNORE_PATHS="_aiidasubmit.sh:cdnc:out:FleurInputSchema.xsd:FleurOutputSchema.xsd:cdn.hdf:usage.json:cdn*:mixing_history*:juDFT_times.json:*.config:*.econfig:struct*.xsf:band.gnu"
export AIIDA_MOCK_REGENERATE_DATA=True

'/usr/local/bin/aiida-mock-code' '-minimalOutput' '-last_extra' '-no_send' '-wtime' '60'  > 'shell.out' 2> 'out.error'
