#!/bin/bash
exec > _scheduler-stdout.txt
exec 2> _scheduler-stderr.txt


export AIIDA_MOCK_LABEL="inpgen"
export AIIDA_MOCK_DATA_DIR="/builds/fleur/aiida-fleur/tests/workflows/calculations"
export AIIDA_MOCK_EXECUTABLE_PATH="/builds/fleur/aiida-fleur/tests/local_exe/inpgen"
export AIIDA_MOCK_IGNORE_FILES="_aiidasubmit.sh:FleurInputSchema.xsd"
export AIIDA_MOCK_REGENERATE_DATA=True

'/usr/local/bin/aiida-mock-code' '-explicit' '-inc' '+all' '-f' 'aiida.in'  > 'shell.out' 2> 'out.error'
